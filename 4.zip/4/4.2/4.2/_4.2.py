a, b, c, d, e = map(int, input())

rez=((d**e)*c)/(a-b)

print(rez)
